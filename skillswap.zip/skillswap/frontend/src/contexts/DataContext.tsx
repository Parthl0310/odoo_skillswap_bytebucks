import React, { createContext, useContext, useState } from 'react';
import { User, SwapRequest, Feedback, Notification, AdminMessage } from '../types';
import { mockUsers, mockSwapRequests, mockFeedback, mockNotifications, mockAdminMessages } from '../data';

interface DataContextType {
  users: User[];
  swapRequests: SwapRequest[];
  feedback: Feedback[];
  notifications: Notification[];
  adminMessages: AdminMessage[];
  createSwapRequest: (request: Omit<SwapRequest, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateSwapRequest: (id: string, updates: Partial<SwapRequest>) => void;
  addFeedback: (feedback: Omit<Feedback, 'id' | 'createdAt'>) => void;
  createAdminMessage: (message: Omit<AdminMessage, 'id' | 'createdAt'>) => void;
  banUser: (userId: string) => void;
  unbanUser: (userId: string) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<User[]>(mockUsers);
  const [swapRequests, setSwapRequests] = useState<SwapRequest[]>(mockSwapRequests);
  const [feedback, setFeedback] = useState<Feedback[]>(mockFeedback);
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications);
  const [adminMessages, setAdminMessages] = useState<AdminMessage[]>(mockAdminMessages);

  const createSwapRequest = (request: Omit<SwapRequest, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newRequest: SwapRequest = {
      ...request,
      id: Date.now().toString(),
      createdAt: new Date(),
      updatedAt: new Date()
    };
    setSwapRequests(prev => [...prev, newRequest]);
  };

  const updateSwapRequest = (id: string, updates: Partial<SwapRequest>) => {
    setSwapRequests(prev => prev.map(req => 
      req.id === id ? { ...req, ...updates, updatedAt: new Date() } : req
    ));
  };

  const addFeedback = (feedbackData: Omit<Feedback, 'id' | 'createdAt'>) => {
    const newFeedback: Feedback = {
      ...feedbackData,
      id: Date.now().toString(),
      createdAt: new Date()
    };
    setFeedback(prev => [...prev, newFeedback]);
  };

  const createAdminMessage = (message: Omit<AdminMessage, 'id' | 'createdAt'>) => {
    const newMessage: AdminMessage = {
      ...message,
      id: Date.now().toString(),
      createdAt: new Date()
    };
    setAdminMessages(prev => [...prev, newMessage]);
  };

  const banUser = (userId: string) => {
    setUsers(prev => prev.map(user => 
      user.id === userId ? { ...user, isBanned: true } : user
    ));
  };

  const unbanUser = (userId: string) => {
    setUsers(prev => prev.map(user => 
      user.id === userId ? { ...user, isBanned: false } : user
    ));
  };

  return (
    <DataContext.Provider value={{
      users,
      swapRequests,
      feedback,
      notifications,
      adminMessages,
      createSwapRequest,
      updateSwapRequest,
      addFeedback,
      createAdminMessage,
      banUser,
      unbanUser
    }}>
      {children}
    </DataContext.Provider>
  );
};