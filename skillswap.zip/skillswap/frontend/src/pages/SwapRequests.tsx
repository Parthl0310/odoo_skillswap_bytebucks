import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';

const SwapRequests: React.FC = () => {
  const { user } = useAuth();
  const { swapRequests, users, updateSwapRequest } = useData();

  if (!user) return null;

  const userSwapRequests = swapRequests.filter(
    req => req.fromUserId === user.id || req.toUserId === user.id
  );

  const handleAccept = (requestId: string) => {
    updateSwapRequest(requestId, { status: 'accepted' });
  };

  const handleReject = (requestId: string) => {
    updateSwapRequest(requestId, { status: 'rejected' });
  };

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-light mb-12 text-center">Swap Requests</h1>

        {userSwapRequests.length === 0 ? (
          <div className="text-center text-gray-400 text-xl">
            No swap requests found
          </div>
        ) : (
          <div className="space-y-8">
            {userSwapRequests.map((request) => {
              const otherUser = users.find(u => 
                u.id === (request.fromUserId === user.id ? request.toUserId : request.fromUserId)
              );
              const isIncoming = request.toUserId === user.id;

              if (!otherUser) return null;

              return (
                <div key={request.id} className="border-2 border-white rounded-3xl p-8">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-8">
                      {/* Profile Photo */}
                      <div className="w-24 h-24 border-2 border-white rounded-full overflow-hidden">
                        {otherUser.photo ? (
                          <img src={otherUser.photo} alt={otherUser.name} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full bg-gray-600 flex items-center justify-center text-sm">
                            Profile Photo
                          </div>
                        )}
                      </div>

                      {/* Request Info */}
                      <div className="space-y-4">
                        <h3 className="text-2xl font-light">{otherUser.name}</h3>
                        
                        <div className="space-y-2">
                          <div className="text-lg">
                            <span className="text-green-400">Skills Offered:</span> {request.skillOffered}
                          </div>
                          <div className="text-lg">
                            <span className="text-blue-400">Skills wanted:</span> {request.skillWanted}
                          </div>
                        </div>

                        {request.message && (
                          <div className="text-gray-300 max-w-md">
                            <span className="text-white">Message:</span> {request.message}
                          </div>
                        )}

                        <div className="text-sm text-gray-400">
                          {isIncoming ? 'Incoming request' : 'Outgoing request'} • {request.createdAt.toLocaleDateString()}
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="text-right space-y-4">
                      <div className={`text-lg font-medium ${
                        request.status === 'pending' ? 'text-yellow-400' :
                        request.status === 'accepted' ? 'text-green-400' :
                        request.status === 'rejected' ? 'text-red-400' :
                        'text-blue-400'
                      }`}>
                        {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                      </div>

                      {isIncoming && request.status === 'pending' && (
                        <div className="space-y-2">
                          <button
                            onClick={() => handleAccept(request.id)}
                            className="block w-full bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors"
                          >
                            Accept
                          </button>
                          <button
                            onClick={() => handleReject(request.id)}
                            className="block w-full bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700 transition-colors"
                          >
                            Reject
                          </button>
                        </div>
                      )}

                      {request.status === 'accepted' && (
                        <div className="text-center">
                          <div className="text-2xl font-light mb-4">Rating and Feedback</div>
                          <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                            Leave Feedback
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default SwapRequests;